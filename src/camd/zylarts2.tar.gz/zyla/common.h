#ifndef atsdk_examplesCommonH
#define atsdk_examplesCommonH

extern const char * sdkErrorString();
extern bool errorOk(int _i_err, const char * _sz_caller);
#endif
